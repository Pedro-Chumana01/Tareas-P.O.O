
package com.mycompany.poo;

public class Alumno {
    //primero creo los atributos de el alumno 
    //lo hago de la siguiente manera
    int id;
    String nombre;
    String apellido;
    //los nombres y apellidos son string
    
    
    //ahora queremos crear un metodo o acciones para mi alumno
    //lo hago un metodo para esto es necesario un modificador de acceso (public)
    
    public Alumno() {
    }

    public Alumno(int id, String nombre, String apellido) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        //this sirve para asignar un valor que recibo como parametro 
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    public void mostrarNombre(int id,String nombre,String Apellido){
        
        System.out.println("hola,soy el alumno y se decir mi nombre ");
        
    }
    
    //yo tambien quiero hacer un metodo para saber si aprobe mediante una calificacion
    //y quiero crear un metodo para eso 
    //lo hago con otro metodo de tipo void 
    
    public void saberAprobado(double calificacion){
        if (calificacion >=14){
            System.out.println("si pude aprobar la materia :)");
        }
        else{
            System.out.println("no pude aprobar la materia");
            
        }
    }
    //listo asi es como se crean los metodos 
    //ahora que ya tenemos las acciones que quiero que haga 
    //necesito un crear un constructor
    
    
    
}

