package com.mycompany.poo;

public class POO {

    public static void main(String[] args) {
        //vamos a crear un alumno : lo hago de la siguiente manera
        Alumno alumno1 = new Alumno ();
        Alumno alumno2 = new Alumno (12,"pedro","chumana");
        
        
        System.out.println("El id de el alumno 2 es :" + alumno2.getId());
        System.out.println("Su nombre el :"+alumno2.getNombre());
        System.out.println("El apellido de el alumno 2 es  : "+alumno2.getApellido());
        
        System.out.println("--------------------");
        alumno1.setId(15);
        alumno1.setNombre("Henry");
        alumno1.setApellido("alvarez");
        
        System.out.println("El id de el alumno 1 es :" + alumno1.getId());
        System.out.println("Su nombre el :"+alumno1.getNombre());
        System.out.println("El apellido de el alumno 1 es  : "+alumno1.getApellido());
        
        System.out.println("----------------");
        alumno2.setId(22);
        System.out.println("El nuevo id de el alumno 2 es :" + alumno2.getId());
        System.out.println("Su nombre el :"+alumno2.getNombre());
        System.out.println("El apellido de el alumno 2 es  : "+alumno2.getApellido());
        
        
        
    }
}
