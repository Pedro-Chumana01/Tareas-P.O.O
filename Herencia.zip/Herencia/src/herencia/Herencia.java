package herencia;

public class Herencia {

    public static void main(String[] args) {
        Planta planta =new Planta();//creo el objeto 
        AnimalCarnivoro animalC = new AnimalCarnivoro();
        AnimalHervivoro animalH = new AnimalHervivoro();
        
        //mando a llamar a la planta o mas bien dicho a su metodo
        planta.alimentarse();
        animalC.alimentarse();
        animalH.alimentarse();
       
        
        
        
        
        
    }
    
}
