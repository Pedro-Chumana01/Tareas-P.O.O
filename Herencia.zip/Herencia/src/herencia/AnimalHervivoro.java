package herencia;

public  class AnimalHervivoro extends Animal{
    
    //agrago el metodo sobreescrito de elimentarse 
   
    @Override
    public  void alimentarse(){
        
        System.out.println("los herviboros se alimentan de plantas ");
    }
    
    
    
}
