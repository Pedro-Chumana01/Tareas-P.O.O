package herencia;

public abstract class SerVivo {
    
    public abstract void alimentarse();
    
  
}
