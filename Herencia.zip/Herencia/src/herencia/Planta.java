
package herencia;

public class Planta extends SerVivo {
    
   //vamos a sobreescribir elte tipo de etodo para practicar con polimorfismo
    
  //agrego el metodo para alimentarse de la plante 
    @Override
    public void alimentarse (){
        System.out.println("la planta se alimenta por la fotosintesis ");
    }
    
}
