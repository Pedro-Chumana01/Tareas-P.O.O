package excepciones;
import java.util.Scanner;1


public class Excepciones {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

        try {
            // Solicitar al usuario que ingrese dos números
            System.out.print("Ingrese el numerador: ");
            int numerador = scanner.nextInt();

            System.out.print("Ingrese el denominador: ");
            int denominador = scanner.nextInt();

            // Realizar la división y manejar posibles excepciones
            int resultado = realizarDivision(numerador, denominador);

            // Mostrar el resultado
            System.out.println("Resultado de la división: " + resultado);

        } catch (ArithmeticException excepcionAritmetica) {
            // Capturar excepción de división por cero
            System.out.println("Error: " + excepcionAritmetica.getMessage());
        } catch (Exception excepcionGeneral) {
            // Capturar cualquier otra excepción
            System.out.println("Error inesperado: " + excepcionGeneral.getMessage());
        } finally {
            // Cerrar el scanner
            scanner.close();
        }
    }

    // Método que realiza la división y puede lanzar una excepción de división por cero
    private static int realizarDivision(int numerador, int denominador) {
        if (denominador == 0) {
            throw new ArithmeticException("No es posible realizar la división, el denominador es cero.");
        }
        return numerador / denominador;
    }
    }
   
