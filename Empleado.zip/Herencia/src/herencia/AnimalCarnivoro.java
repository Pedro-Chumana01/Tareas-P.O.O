package herencia;

public class AnimalCarnivoro extends Animal {
    // aqui debo agregar el metodo de alimentarsr
    
    //ya que voy a usar una forma distinta de alimentarse uso 
    //override para que sobreescriba la forma de alimentarse en una nueva forma 
    //polimorfismo
    @Override
    public  void alimentarse(){
        System.out.println("los carnivoros se alimentan de carne");
    }
    
    
    
    
}
