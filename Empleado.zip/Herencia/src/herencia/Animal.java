package herencia;

public abstract class Animal extends SerVivo{
     
    //implemento el metodo para crear el tipo de alimentacion
    //como tenemos que ver que tipo de animal es si es herviboro o carnivoro 
     //necesito heredar el metodo de alimentarse para ambos 
    
     @Override
     public abstract void alimentarse ();
}
