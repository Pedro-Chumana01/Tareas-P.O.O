
package ejemploforeach;
import java.util.ArrayList;

public class EjemploForEach {

    public static void main(String[] args) {
        // Creamos una lista de nombres
        ArrayList<String> nombres = new ArrayList<>();
        nombres.add("Juan");
        nombres.add("Maria");
        nombres.add("Carlos");
        nombres.add("Ana");

        // Utilizamos un bucle foreach para recorrer la lista
        for (String nombre : nombres) {
            // Imprimimos un saludo personalizado para cada nombre
            System.out.println("Hola, " + nombre + "!");
        }
    }
    
}
