package encapsulamiento;

public class Encapsulamiento {

    public static void main(String[] args) {
    //crear un objeto llamado alumno
    Alumno alumno = new Alumno ();
    Alumno alumno2 = new Alumno(22,"Pedro","Chumana");
    System.out.println("the id for the student is  :"+ alumno2.getId());
    System.out.println("the name of the student is : "+ alumno2.getNombre());
    System.out.println("the last name the student is : " + alumno2.getApellido());
            
    }
    
}
