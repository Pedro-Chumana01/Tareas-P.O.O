/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoanimales;

/**
 *
 * @author kendr
 */
public class ProyectoAnimales {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        // Crear instancias de Gato y Perro
        Gato gato1 = new Gato("Pelusa", 3);
        Perro perro1 = new Perro("Max", 2);

        // Llamar a métodos
        System.out.println(gato1.getNombre() + " tiene " + gato1.getEdad() + " anos y hace ");
        gato1.hacerRuido();

        System.out.println(perro1.getNombre() + " tiene " + perro1.getEdad() + " anos y hace ");
        perro1.hacerRuido();
    }
        
    }
    
