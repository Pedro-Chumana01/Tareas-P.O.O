/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoanimales;

/**
 *
 * @author kendr
 */
class Gato {
    // Atributos
    private String nombre;
    private int edad;

    // Constructor
    public Gato(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // Método para maullar
    public void hacerRuido() {
        System.out.println("¡Miau!");
    }

    // Métodos para obtener nombre y edad
    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }
    
}
