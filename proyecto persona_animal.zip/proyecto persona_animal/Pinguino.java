/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programacion.orientada.a.objetos;

/**
 *
 * @author Yannick
 */
public class Pinguino extends Zoo {
    public Pinguino(String nombrePublico, int numeroRegistro) {
        super(nombrePublico, numeroRegistro);
    }

    public void nadar() {
        System.out.println("El pinguino en el zoo esta nadando.");
    }

    public void pescar() {
        System.out.println("El pinguino en el zoo esta pescando.");
    }
}




   
