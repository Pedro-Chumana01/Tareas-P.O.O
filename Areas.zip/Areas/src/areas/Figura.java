package areas;

import java.util.Scanner;

public class Figura {
    protected String nombre;

    public Figura(String nombre) {
        this.nombre = nombre;
    }

    public void calcularArea() {
        System.out.println("Area de la figura no especificada");
    }
}

