package areas;
import java.util.Scanner;
public class Circulo extends Figura {
    private double radio;

    public Circulo(String nombre) {
        super(nombre);
    }

    public void ingresarDatos() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el radio del circulo " + nombre + ": ");
        radio = scanner.nextDouble();
    }

    @Override
    public void calcularArea() {
        double area = Math.PI * Math.pow(radio, 2);
        System.out.println("Área del circulo " + nombre + ": " + area);
    }
}

