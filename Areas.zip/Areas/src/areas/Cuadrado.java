package areas;
import java.util.Scanner;
public class Cuadrado extends Figura {
    private double lado;

    public Cuadrado(String nombre) {
        super(nombre);
    }

    public void ingresarDatos() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el lado del cuadrado " + nombre + ": ");
        lado = scanner.nextDouble();
    }

    @Override
    public void calcularArea() {
        double area = Math.pow(lado, 2);
        System.out.println("Area del cuadrado " + nombre + ": " + area);
    }
}

