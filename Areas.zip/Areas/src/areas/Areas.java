
package areas;

public class Areas {

    public static void main(String[] args) {
        Circulo circulo = new Circulo("Circulo1");
        circulo.ingresarDatos();
        circulo.calcularArea();

        Cuadrado cuadrado = new Cuadrado("Cuadrado1");
        cuadrado.ingresarDatos();
        cuadrado.calcularArea();
    }
}

