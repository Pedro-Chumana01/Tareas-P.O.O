package zoo;

import java.util.Scanner;

public class Zoo {

    public static void main(String[] args) {
        Leon leon = new Leon();
        leon.ingresarInformacion();
        leon.hacerSonido();
        leon.mostrarInformacion();

        Pinguino pinguino = new Pinguino();
        pinguino.ingresarInformacion();
        pinguino.hacerSonido();
        pinguino.mostrarInformacion();
    }
}



