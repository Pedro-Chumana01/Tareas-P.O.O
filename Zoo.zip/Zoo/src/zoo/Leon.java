package zoo;

public class Leon extends Animal {

    @Override
    public void hacerSonido() {
        System.out.println("Rugido del león");
    }

    public void mostrarInformacion() {
        System.out.println("Nombre del león: " + nombre);
        System.out.println("Edad del león: " + edad);
    }
}
