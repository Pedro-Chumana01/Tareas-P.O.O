
package zoo;

import java.util.Scanner;

public class Animal {
    protected String nombre;
    protected int edad;

    public void ingresarInformacion() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre del animal: ");
        nombre = scanner.nextLine();

        System.out.print("Ingrese la edad del animal: ");
        edad = scanner.nextInt();
    }

    public void hacerSonido() {
        System.out.println("Sonido del animal en el zoológico");
    }
}


