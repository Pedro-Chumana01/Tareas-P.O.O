package zoo;


public class Pinguino extends Animal {

    @Override
    public void hacerSonido() {
        System.out.println("Sonido del pingüino");
    }

    public void mostrarInformacion() {
        System.out.println("Nombre del pingüino: " + nombre);
        System.out.println("Edad del pingüino: " + edad);
    }
}

