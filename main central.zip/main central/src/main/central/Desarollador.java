package main.central;

class Desarrollador extends Empleado {
    private String lenguajeDeProgramacion;

    public Desarrollador(String nombre, String apellido, int edad, String lenguajeDeProgramacion) {
        super(nombre, apellido, edad);
        this.lenguajeDeProgramacion = lenguajeDeProgramacion;
    }

    @Override
    public void mostrar_informacion() {
        super.mostrar_informacion();
        System.out.println("Lenguaje de programación: " + lenguajeDeProgramacion);
    }
}
