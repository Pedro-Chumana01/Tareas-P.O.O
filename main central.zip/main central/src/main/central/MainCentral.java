package main.central;

import java.util.Scanner;

public class MainCentral {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean datosCorrectos;

        do {
            try {
                System.out.print("Ingrese el nombre del empleado: ");
                String nombre = scanner.nextLine();
                System.out.print("Ingrese el apellido del empleado: ");
                String apellido = scanner.nextLine();
                System.out.print("Ingrese el salario del empleado: ");
                double salario = Double.parseDouble(scanner.nextLine());
                System.out.print("Ingrese la edad del empleado: ");
                int edad = Integer.parseInt(scanner.nextLine());
                System.out.print("Ingrese el lenguaje que utiliza el empleado: ");
                String lenguajeDeProgramacion = scanner.nextLine();

                Desarrollador desarrollador1 = new Desarrollador(nombre, apellido, edad, lenguajeDeProgramacion);
                desarrollador1.setSalario(salario);

                System.out.println("\n");
                desarrollador1.calcular_bono();
                System.out.println("\n");
                desarrollador1.mostrar_informacion();

                datosCorrectos = true;

            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un número válido para la edad o salario.");
                datosCorrectos = false;
            }
        } while (!datosCorrectos);

        System.out.println("Se registró el Desarrollador");

        do {
            try {
                System.out.print("Ingrese el nombre del empleado: ");
                String nombre = scanner.nextLine();
                System.out.print("Ingrese el apellido del empleado: ");
                String apellido = scanner.nextLine();
                System.out.print("Ingrese el salario del empleado: ");
                double salario = Double.parseDouble(scanner.nextLine());
                System.out.print("Ingrese la edad del empleado: ");
                int edad = Integer.parseInt(scanner.nextLine());
                System.out.print("Ingrese el departamento del empleado: ");
                String departamento = scanner.nextLine();

                Gerente gerente1 = new Gerente(nombre, apellido, edad, departamento);
                gerente1.setSalario(salario);

                gerente1.calcular_bono();
                gerente1.mostrar_informacion();

                datosCorrectos = true;

            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un número válido para la edad o salario.");
                datosCorrectos = false;
            }
        } while (!datosCorrectos);

        System.out.println("Se registró el Gerente");
    }
}

