package main.central;

class Gerente extends Empleado {
    private String departamento;

    public Gerente(String nombre, String apellido, int edad, String departamento) {
        super(nombre, apellido, edad);
        this.departamento = departamento;
    }

    @Override
    public void mostrar_informacion() {
        super.mostrar_informacion();
        System.out.println("Departamento: " + departamento);
    }
}