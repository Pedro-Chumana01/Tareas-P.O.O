
package main.central;
import java.util.Scanner;

public class Empleado {
    private String nombre;
    private String apellido;
    private int edad;
    private double salario;
    //debo crear 2 constructores 
    //constructor publico
    public Empleado(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
     //constructor privado
    public double setSalario(double salario) {
        this.salario = salario;
        return salario;
    }
    
    //metodopara calcular el bono 
     public void calcular_bono() {
        // Lógica para calcular bono (puedes personalizar según necesites)
        System.out.println("Calculando bono para el empleado...");
    }
     
     
     //metodo para mostrar informacion
    public void mostrar_informacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Edad: " + edad);
        System.out.println("Salario: $" + salario);
    }
     }
